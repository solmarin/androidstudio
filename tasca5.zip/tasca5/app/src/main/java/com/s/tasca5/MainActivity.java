package com.s.tasca5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements FragmentA.OnFragmentInteractionListener,FragmentB.OnFragmentInteractionListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentA fA  = new FragmentA();
        getSupportFragmentManager().beginTransaction().add(R.id.frameLayout,fA);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.imagen:
                FragmentA fA = new FragmentA();
                FragmentTransaction transition = getSupportFragmentManager().beginTransaction();
                transition.replace(R.id.frameLayout, fA);
                transition.commit();
                return true;
            case R.id.lista:
                FragmentB fB = new FragmentB();
                FragmentTransaction transition2 = getSupportFragmentManager().beginTransaction();
                transition2.replace(R.id.frameLayout, fB);
                transition2.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
