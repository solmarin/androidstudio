package com.example.tasca_1_manipulacio;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.os.Bundle;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button sum,rest,augmentar,disminuir,amagar,mostrar,colorText,colorFons;

    private int cont;
    private int size = 14;
    private int rdText = Color.parseColor("#000000"),rdBackground;
    private boolean visible=true;
    private TextView num;
    final Random rdn = new Random();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num = findViewById(R.id.textViewCounter);

        sum = findViewById(R.id.btSumar);
        rest = findViewById(R.id.btRestar);
        augmentar = findViewById(R.id.btAugmentar);
        disminuir = findViewById(R.id.btDisminuir);
        amagar = findViewById(R.id.btAmagar);
        mostrar = findViewById(R.id.btMostrar);
        colorText = findViewById(R.id.btColorText);
        colorFons= findViewById(R.id.btColorFons);

        sum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont++;
                num.setText(String.valueOf(cont));
            }
        });

        rest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont--;
                num.setText(String.valueOf(cont));
            }
        });

        augmentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               if (size < 30){
                   size++;
                   num.setTextSize(size);
               }
            }
        });

        disminuir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (size > 10){
                    size--;
                    num.setTextSize(size);
                }
            }
        });
        amagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num.setVisibility(View.INVISIBLE);
                visible = false;
            }
        });

        mostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num.setVisibility(View.VISIBLE);
                visible = true;
            }
        });

        colorText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rdText = rdn.nextInt();
                num.setTextColor(rdText);
            }
        });

        colorFons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rdBackground = rdn.nextInt();
                num.setBackgroundColor(rdBackground);
            }
        });
    }

    @Override
    public void onSaveInstanceState( Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("Size",size);
        outState.putInt("Counter",cont);
        outState.putBoolean("Visible",visible);
        outState.putInt("TextColor",rdText);
        outState.putInt("BackgroundColor",rdBackground);

    }

    @Override
    protected void onRestoreInstanceState( Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        /*
         *
         * Get content of the save point
         *
         */
        if (savedInstanceState != null) {

            cont = savedInstanceState.getInt("Counter");
            size = savedInstanceState.getInt("Size");
            visible = savedInstanceState.getBoolean("Visible");
            rdText = savedInstanceState.getInt("TextColor");
            rdBackground = savedInstanceState.getInt("BackgroundColor");

            /*
             *
             * Set content in layout
             *
             */

            num.setText(String.valueOf(cont));
            num.setTextSize(size);
            if( !visible ) {
                num.setVisibility(View.INVISIBLE);
            }
            num.setTextColor(this.rdText);
            num.setBackgroundColor(rdBackground);

        }


    }


}

















        /*number = (TextView) findViewById(R.id.id_num);
        sum = findViewById(R.id.btSumar);
        sum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont++;
                number.setText(cont);
            }
        });

        rest = findViewById(R.id.btRestar);
        rest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cont--;
                number.setText(cont);
            }
    });*/




