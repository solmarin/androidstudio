package com.smme.tasca2animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   //VARIABLES GLOBALES
    ImageView img;
    TextView txt;
    SeekBar seekBarVel;
    int duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seekBarVel = (SeekBar) findViewById(R.id.seekBar);
        img = (ImageView) findViewById(R.id.android);
        txt = (TextView) findViewById((R.id.textView));


        seekBarVel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            //cambiar el volum den objeto sonante por el marcado en el seekbar
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                duration = progress;

            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub

            }

            //mostrar volum al soltar el seekbar
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this,"VEL:"+ duration,
                        Toast.LENGTH_SHORT).show();
            }
        });


    }

    //FUNCIONES ONCLICK PARA LOS BOTONES

    //Fade in
   public void clickFadeIn(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fadein);
       anim.setDuration(duration);
       img.startAnimation(anim);
       txt.setText("RUNNING");

    }
    //Fade out
    public void clickFadeOut(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fadeout);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //Zoom in
    public void clickZoomIn(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomin);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //Zoom out
    public void clickZoomOut(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomout);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //Left right
    public void clickLeftRight(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.leftright);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //Top bottom
    public void clickTopBottom(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.topbottom);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //Bounce
    public void clickBounce(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bounce);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //Flash
    public void clickFlash(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.flash);
        anim.setDuration(duration);
        img.startAnimation(anim);
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        }


    }        ;
        txt.setText("RUNNING");
    }
    //Rotate
    public void clickRotate(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    //several
    public void clickSeveral(View v){
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.several);
        anim.setDuration(duration);
        img.startAnimation(anim);
        txt.setText("RUNNING");
    }

    public void onAnimationEnd(Animation anim){
        txt.setText("STOP");
    }
}
