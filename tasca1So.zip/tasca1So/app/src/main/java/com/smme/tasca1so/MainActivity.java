package com.smme.tasca1so;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    SoundPool sp;
    int playing1;
    int playing2;
    int musica1;
    int musica2;
    SeekBar volumControl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        volumControl = (SeekBar) findViewById(R.id.seekBar);


        //INICIALIZAR CLASE SOUNDPOOL
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            AudioAttributes audioAttributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            sp = new SoundPool.Builder().setMaxStreams(5).setAudioAttributes(audioAttributes).build();
        }else{
            sp = new SoundPool(5, AudioManager.STREAM_MUSIC,0);
        }

        musica1 = sp.load(this,R.raw.heavyrainloop,0);
        musica2 = sp.load(this, R.raw.hurricane, 0);

        volumControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            float cProgress = 0;

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                cProgress = progress;
                sp.setVolume(playing1,(float) cProgress/100,(float) cProgress/100);
                sp.setVolume(playing2,(float) cProgress/100,(float) cProgress/100);
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub

            }


            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(MainActivity.this,"VOLUM:"+ cProgress,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    //funcions per els botons play y stop
    public void play1(View v){

        playing1 = sp.play(musica1, 1,1,0,0,1);

    }

    public void play2(View v){

        playing2 = sp.play(musica2,1,1,0,0,1);
    }

    public void stop(View v){
        sp.stop(playing1);
        sp.stop(playing2);
    }



}
