package com.example.tasca5;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.media.Image;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.AttributeSet;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private PagIMG fragmentImage;
    private PagList fragmentList;
    int showingFragment = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentImage = new PagIMG();
        fragmentList = new PagList();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frameLayout, fragmentImage);
        fragmentTransaction.commit();



        showingFragment=1;

    }



      /*@Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {


        switch (item.getItemId()) {
            case R.id.CtxLblOpc1:
                Toast.makeText(this,"Etiqueta: Opcion 1 pulsada!",Toast.LENGTH_LONG).show();

                return true;
            case R.id.CtxLblOpc2:
                Toast.makeText(this,"Etiqueta: Opcion 2 pulsada!",Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }

    }*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_1, menu);
        return true;
        //return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_contextual, menu);

    }


    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if (item.getItemId() == R.id.opcion1){

            Toast.makeText(this,"Image",Toast.LENGTH_LONG).show();
            fragmentTransaction.replace(R.id.frameLayout, fragmentImage);

            showingFragment = 1;

        }else if (item.getItemId() == R.id.opcion2){

            Toast.makeText(this, "Llista",Toast.LENGTH_LONG).show();
            fragmentTransaction.replace(R.id.frameLayout, fragmentList);

            showingFragment = 2;

        }else{
            return super.onContextItemSelected(item);
        }
        fragmentTransaction.commit();

        return true;
    }



}
