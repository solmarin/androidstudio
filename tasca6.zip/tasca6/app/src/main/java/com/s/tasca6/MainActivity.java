package com.s.tasca6;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private String[] componentes = {"Gatos", "Perros", "Pajaros", "Camellos", "Pollos", "Ballenas", "Patos", "Informaticos"};
    ImageView image ;
    int visibilidad = View.VISIBLE;



    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,componentes);

        image = (ImageView) findViewById(R.id.imageButton);
        registerForContextMenu(image);
        cargarPreferencias();

        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               view.setBackgroundColor(Color.BLUE);

            }
        });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
    }


    public boolean onContextItemSelected(MenuItem item) {

        ImageView image = (ImageView) findViewById(R.id.imageButton);
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.hide:
                image.setVisibility(View.INVISIBLE);
                visibilidad = View.INVISIBLE;
                break;

            default:
                image.setVisibility(View.VISIBLE);
                visibilidad = View.VISIBLE;
                return super.onContextItemSelected(item);


        }
        guardarPreferencias();
        return false;

    }


    private void cargarPreferencias() {
        SharedPreferences preferences = getSharedPreferences("V",Context.MODE_PRIVATE);

        String vis = preferences.getString("v","0");
        image.setVisibility(Integer.parseInt(vis));

    }


    private void guardarPreferencias() {
        SharedPreferences preferences = getSharedPreferences("V",Context.MODE_PRIVATE);
        String v = String.valueOf(visibilidad);

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("v", v);

        image.setVisibility(Integer.parseInt(v));

        editor.commit();



    }




}
